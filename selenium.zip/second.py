import unittest
import time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver import Edge


class PythonOrgSearch(unittest.TestCase):

    def setUp(self):
        self.driver = Edge()
        self.inicio = ["ICU", "Tech1586*"]

    def dothis(self, usuario, contra):
        driver = self.driver
        driver.get("https://agente.gbr-tech.com/laravel/login")
        driver.set_window_size(1200, 940)
        time.sleep(1)
        user = driver.find_element_by_name("username")
        user.clear()
        user.send_keys(usuario)
        pss = driver.find_element_by_name("password")
        pss.clear()
        pss.send_keys(contra)
        btn = driver.find_element_by_css_selector(".btn-lg")
        btn.click()

    def test_buscar_auto(self):
        driver = self.driver
        self.dothis(self.inicio.append[0], self.inicio.append[1])
        time.sleep(5)

        buscar = driver.find_element_by_id("searchAll")
        buscar.clear()
        buscar.send_keys("Toyota")
        time.sleep(5)

        auto = driver.find_element_by_css_selector(".sidebar-row:nth-child(1)")
        auto.click()
        auto.click()
        time.sleep(5)

    def test_cambiar_idioma(self):
        driver = self.driver
        self.dothis(self.inicio)
        time.sleep(5)

    def tearDown(self):
        self.driver.close()


if __name__ == "__main__":
    unittest.main()
# driver.close()
